<?php
    function makeList($array) { 

        //Base case: an empty array produces no list 
        if (empty($array)) return ''; 

        //Recursive Step: make a list with child lists 
        $output = '<ul>'; 
        foreach ($array as $key => $subArray) { 
            $output .= '<li>' . $subArray['data']['cat-id'] . '-' . $subArray['data']['cat-name'] . makeList($subArray['ch']) . '</li>'; 
        } 
        $output .= '</ul>'; 
         
        return $output; 
    } 
?>

<div id="sf_admin_container">

<h1><?php echo 'allegro GetCatsData' ?></h1>

<div id="sf_admin_header"></div>

<table class="filter_and_table_container">
<tbody>
<tr>
<td id="td_sf_admin_bar" class="allegro">

<div id="sf_admin_bar" class="allegro">
<ul>
    <li><?php echo link_to('Cats list', 'allegro/view?method=GetCatsData') ?></li>
    <li><?php echo link_to('My Account', 'allegro/myAccount') ?></li>
</ul>
</div>

</td>
<td id="td_sf_admin_content">

<div id="sf_admin_content">
<table>
<thead>
<tr>
  <th>cat-id</th>
  <th>cat-name</th>
  <th>cat-parent</th>
  <th>cat-position</th>
</tr>
</thead>
<tbody>
<?php echo makeList($childs); ?>
</tbody>
</table>
</div>

</td>
</tr>
</tbody>
</table>

<div id="sf_admin_footer">

</div>

</div>

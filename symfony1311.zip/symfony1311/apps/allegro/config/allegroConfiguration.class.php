<?php

class allegroConfiguration extends sfApplicationConfiguration
{
  public function configure()
  {
  }
}
